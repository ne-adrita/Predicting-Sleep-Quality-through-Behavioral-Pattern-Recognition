import pandas as pd
import numpy as np
import lightgbm as lgb
import pickle
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (
    mean_absolute_error, mean_squared_error, r2_score,
    accuracy_score, classification_report, confusion_matrix
)

print("🚀 Starting LightGBM Model Training...")

# 📂 Step 1: Load and Clean Dataset
print("📂 Loading dataset...")
df = pd.read_csv('sleep_pattern_analysis_datasett.csv')
print(f"Dataset shape: {df.shape}")

# Drop Person_ID column
df.drop(columns=['Person_ID'], inplace=True)
print("✅ Dropped Person_ID column")

# 📊 Step 2: Data Preprocessing
print("🔧 Preprocessing data...")

# Handle missing values - replace empty strings and spaces with NaN
df = df.replace('', np.nan)
df = df.replace(' ', np.nan)

# Define numeric and categorical columns
numeric_columns = ['Age', 'Sleep Start Time', 'Sleep End Time', 'Total Sleep Hours', 
                  'Exercise (mins/day)', 'Caffeine Intake (mg)', 'Screen Time Before Bed (mins)',
                  'Work Hours (hrs/day)', 'Productivity Score', 'Mood Score', 'Stress Level']
categorical_columns = ['Gender']

# Convert numeric columns to float, handling any conversion errors
for col in numeric_columns:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# Fill missing values in numeric columns only
df[numeric_columns] = df[numeric_columns].fillna(df[numeric_columns].mean())

# Label Encode Categorical Columns
categorical_cols = ['Gender']
label_encoders = {}

for col in categorical_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le
    print(f"✅ Encoded {col}")

# 🎯 Step 3: Define Features and Targets
# Use 'Sleep Quality' as the target variable
X = df.drop(columns=['Sleep Quality'])
y_reg = df['Sleep Quality']  # Regression target (continuous)
y_class = y_reg.apply(lambda x: 0 if x <= 3 else (1 if x <= 6 else 2))  # Classification target

print(f"Features shape: {X.shape}")
print(f"Regression target shape: {y_reg.shape}")
print(f"Classification target shape: {y_class.shape}")

# ⚖️ Step 4: Feature Scaling
print("⚖️ Scaling features...")
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_scaled = pd.DataFrame(X_scaled, columns=X.columns)

# 🔀 Step 5: Train/Test Split
X_train_r, X_test_r, y_train_r, y_test_r = train_test_split(X_scaled, y_reg, test_size=0.2, random_state=42)
X_train_c, X_test_c, y_train_c, y_test_c = train_test_split(X_scaled, y_class, test_size=0.2, random_state=42)

print(f"Training set size: {X_train_r.shape[0]}")
print(f"Test set size: {X_test_r.shape[0]}")

# 🟢 Step 6A: Train LightGBM Regression Model
print("🧠 Training LightGBM Regression Model...")
regressor = lgb.LGBMRegressor(
    random_state=42,
    n_estimators=100,
    learning_rate=0.1,
    max_depth=6
)
regressor.fit(X_train_r, y_train_r)
y_pred_r = regressor.predict(X_test_r)

print("📊 Regression Evaluation (LightGBM)")
print(f"MAE: {mean_absolute_error(y_test_r, y_pred_r):.4f}")
print(f"MSE: {mean_squared_error(y_test_r, y_pred_r):.4f}")
print(f"R² Score: {r2_score(y_test_r, y_pred_r):.4f}")

# 🟢 Step 6B: Train LightGBM Classification Model
print("\n🧠 Training LightGBM Classification Model...")
classifier = lgb.LGBMClassifier(
    random_state=42,
    n_estimators=100,
    learning_rate=0.1,
    max_depth=6
)
classifier.fit(X_train_c, y_train_c)
y_pred_c = classifier.predict(X_test_c)

print("📊 Classification Evaluation (LightGBM)")
print(f"Accuracy: {accuracy_score(y_test_c, y_pred_c):.4f}")
print("Confusion Matrix:")
print(confusion_matrix(y_test_c, y_pred_c))
print("Classification Report:")
print(classification_report(y_test_c, y_pred_c, target_names=["Poor", "Average", "Good"]))

# 💾 Step 7: Save Models and Preprocessing Objects
print("\n💾 Saving models and preprocessing objects...")

# Create a dictionary with all necessary objects
model_objects = {
    'regressor': regressor,
    'classifier': classifier,
    'scaler': scaler,
    'label_encoders': label_encoders,
    'feature_names': list(X.columns),
    'categorical_cols': categorical_cols
}

# Save the model objects
with open('lightgbm_model.pkl', 'wb') as f:
    pickle.dump(model_objects, f)

print("✅ Models saved successfully!")
print("📁 Saved files:")
print("   - lightgbm_model.pkl (contains both regression and classification models)")

# 🧪 Step 8: Test the saved model
print("\n🧪 Testing saved model...")
try:
    with open('lightgbm_model.pkl', 'rb') as f:
        test_objects = pickle.load(f)
    
    # Test with sample data
    sample_data = X_test_r.iloc[0:1]
    reg_pred = test_objects['regressor'].predict(sample_data)[0]
    class_pred = test_objects['classifier'].predict(sample_data)[0]
    
    print(f"Sample regression prediction: {reg_pred:.2f}")
    print(f"Sample classification prediction: {class_pred} (0=Poor, 1=Average, 2=Good)")
    
    print("\n🎉 Model training and saving completed successfully!")
    print("📋 Model Summary:")
    print(f"   - Regression R² Score: {r2_score(y_test_r, y_pred_r):.4f}")
    print(f"   - Classification Accuracy: {accuracy_score(y_test_c, y_pred_c):.4f}")
    print(f"   - Features used: {len(X.columns)}")
    print(f"   - Training samples: {X_train_r.shape[0]}")
    print(f"   - Test samples: {X_test_r.shape[0]}")
    
except Exception as e:
    print(f"❌ Error testing saved model: {e}") 