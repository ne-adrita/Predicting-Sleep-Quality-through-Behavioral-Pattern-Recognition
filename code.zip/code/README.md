# Sleep Quality Prediction with LightGBM

This project implements a sleep quality prediction system using LightGBM (Gradient Boosting) algorithm. The system provides both regression (continuous score) and classification (Poor/Average/Good) predictions based on various health and lifestyle factors.

## 🚀 Features

- **LightGBM Model**: High-performance gradient boosting algorithm
- **Dual Prediction**: Both regression (0-10 score) and classification (Poor/Average/Good)
- **Web Interface**: Beautiful Flask-based web application
- **API Endpoint**: RESTful API for programmatic access
- **Real-time Predictions**: Instant sleep quality predictions

## 📊 Model Performance

- **Regression R² Score**: ~0.99 (Excellent)
- **Classification Accuracy**: ~0.95 (Very High)
- **Features**: 10 health and lifestyle factors
- **Training Data**: 15,000+ samples

## 🛠️ Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd sleep-quality-prediction
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Train the model**:
   ```bash
   python train_lightgbm_model.py
   ```

4. **Test the model**:
   ```bash
   python test_model.py
   ```

5. **Run the web application**:
   ```bash
   python app.py
   ```

## 📁 Project Structure

```
├── app.py                          # Flask web application
├── train_lightgbm_model.py         # Model training script
├── test_model.py                   # Model testing script
├── requirements.txt                 # Python dependencies
├── lightgbm_model.pkl             # Trained model (generated)
├── templates/                      # HTML templates
│   ├── index.html                 # Home page
│   └── predictor.html             # Prediction form
├── static/                        # CSS and static files
│   └── styles.css                 # Styling
└── Ml Algorithms/                 # Original ML notebooks
    ├── LightGBM_up.ipynb         # LightGBM training notebook
    └── Sleep_Data_Sampled(missing_Dis).csv  # Dataset
```

## 🎯 Usage

### Web Interface

1. Start the Flask app:
   ```bash
   python app.py
   ```

2. Open your browser and go to:
   ```
   http://localhost:5001
   ```

3. Fill in the prediction form with your data:
   - **Personal Information**: Age, Gender, Occupation
   - **Sleep Patterns**: Sleep Duration, Daily Steps
   - **Health Metrics**: BMI Category, Blood Pressure, Heart Rate
   - **Lifestyle Factors**: Physical Activity Level, Stress Level

4. Click "Predict Sleep Quality" to get your results

### API Usage

The system also provides a REST API endpoint:

```bash
curl -X POST http://localhost:5001/api/predict \
  -H "Content-Type: application/json" \
  -d '{
    "Gender": "Male",
    "Age": 35,
    "Occupation": "Engineer",
    "Sleep Duration": 7.5,
    "Physical Activity Level": 60,
    "Stress Level": 5,
    "BMI Category": "Normal",
    "Blood Pressure": "120/80",
    "Heart Rate": 70,
    "Daily Steps": 7500
  }'
```

Response:
```json
{
  "success": true,
  "regression_score": 7.85,
  "classification_quality": "Good",
  "classification_score": 2,
  "message": "Sleep Quality Score: 7.85/10 (Good)"
}
```

### Health Check

Check if the model is loaded correctly:
```bash
curl http://localhost:5001/health
```

## 📈 Model Details

### Features Used

1. **Gender**: Male/Female
2. **Age**: 18-100 years
3. **Occupation**: Various professions
4. **Sleep Duration**: Hours of sleep per night
5. **Physical Activity Level**: 1-100 scale
6. **Stress Level**: 1-10 scale
7. **BMI Category**: Normal/Overweight/Obese
8. **Blood Pressure**: Systolic/Diastolic
9. **Heart Rate**: Beats per minute
10. **Daily Steps**: Step count per day

### Prediction Types

- **Regression**: Continuous score from 0-10
- **Classification**: 
  - 0: Poor (≤4)
  - 1: Average (5-7)
  - 2: Good (≥8)

## 🔧 Technical Details

### Model Architecture

- **Algorithm**: LightGBM (Gradient Boosting)
- **Preprocessing**: Label Encoding + Standard Scaling
- **Validation**: Train/Test Split (80/20)
- **Hyperparameters**: Optimized for sleep quality prediction

### Data Preprocessing

1. **Label Encoding**: Categorical variables converted to numerical
2. **Feature Scaling**: StandardScaler for numerical features
3. **Missing Value Handling**: Robust preprocessing pipeline

### Performance Metrics

- **Regression**: R² Score, MAE, MSE
- **Classification**: Accuracy, Precision, Recall, F1-Score

## 🚀 Deployment

### Local Development

```bash
# Install dependencies
pip install -r requirements.txt

# Train model
python train_lightgbm_model.py

# Run application
python app.py
```

### Production Deployment

1. **Using Gunicorn**:
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5001 app:app
   ```

2. **Using Docker**:
   ```dockerfile
   FROM python:3.9-slim
   COPY . /app
   WORKDIR /app
   RUN pip install -r requirements.txt
   EXPOSE 5001
   CMD ["python", "app.py"]
   ```

## 🐛 Troubleshooting

### Common Issues

1. **Model not found**:
   ```bash
   python train_lightgbm_model.py
   ```

2. **Dependencies missing**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Port already in use**:
   Change port in `app.py`:
   ```python
   app.run(debug=True, port=5002)  # Change to different port
   ```

### Debug Mode

Enable debug mode for detailed error messages:
```python
app.run(debug=True, port=5001)
```

## 📝 API Documentation

### Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Home page |
| `/predict` | POST | Web form prediction |
| `/api/predict` | POST | JSON API prediction |
| `/health` | GET | Health check |

### Request Format

```json
{
  "Gender": "string",
  "Age": "number",
  "Occupation": "string",
  "Sleep Duration": "number",
  "Physical Activity Level": "number",
  "Stress Level": "number",
  "BMI Category": "string",
  "Blood Pressure": "string",
  "Heart Rate": "number",
  "Daily Steps": "number"
}
```

### Response Format

```json
{
  "success": "boolean",
  "regression_score": "number",
  "classification_quality": "string",
  "classification_score": "number",
  "message": "string"
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 👥 Authors

- **Noshin Ebnat Adrita** - Initial work

## 🙏 Acknowledgments

- LightGBM development team
- Scikit-learn community
- Flask framework contributors

---

**Note**: This system is for educational and research purposes. Always consult healthcare professionals for medical advice. 