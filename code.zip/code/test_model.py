import pickle
import pandas as pd
import numpy as np

def test_lightgbm_model():
    """Test the LightGBM model with sample data"""
    
    try:
        # Load the model
        print("🔍 Loading LightGBM model...")
        with open('lightgbm_model.pkl', 'rb') as f:
            model_objects = pickle.load(f)
        
        regressor = model_objects['regressor']
        classifier = model_objects['classifier']
        scaler = model_objects['scaler']
        label_encoders = model_objects['label_encoders']
        feature_names = model_objects['feature_names']
        categorical_cols = model_objects['categorical_cols']
        
        print("✅ Model loaded successfully!")
        print(f"📊 Features: {feature_names}")
        
        # Create sample test data
        sample_data = {
            'Gender': 'Male',
            'Age': 35,
            'Occupation': 'Engineer',
            'Sleep Duration': 7.5,
            'Physical Activity Level': 60,
            'Stress Level': 5,
            'BMI Category': 'Normal',
            'Blood Pressure': '120/80',
            'Heart Rate': 70,
            'Daily Steps': 7500
        }
        
        print("\n🧪 Testing with sample data:")
        for key, value in sample_data.items():
            print(f"   {key}: {value}")
        
        # Create DataFrame
        input_df = pd.DataFrame([sample_data])
        
        # Preprocess the data
        df = input_df.copy()
        
        # Apply label encoding to categorical columns
        for col in categorical_cols:
            if col in df.columns and col in label_encoders:
                unique_values = label_encoders[col].classes_
                df[col] = df[col].apply(lambda x: x if x in unique_values else unique_values[0])
                df[col] = label_encoders[col].transform(df[col])
        
        # Ensure all required columns are present
        for col in feature_names:
            if col not in df.columns:
                df[col] = 0
        
        # Reorder columns to match training data
        df = df[feature_names]
        
        # Apply scaling
        scaled_data = scaler.transform(df)
        scaled_df = pd.DataFrame(scaled_data, columns=feature_names)
        
        # Make predictions
        reg_prediction = regressor.predict(scaled_df)[0]
        class_prediction = classifier.predict(scaled_df)[0]
        
        # Convert classification prediction to text
        quality_map = {0: "Poor", 1: "Average", 2: "Good"}
        quality_text = quality_map.get(class_prediction, "Unknown")
        
        print(f"\n📊 Prediction Results:")
        print(f"   Regression Score: {reg_prediction:.2f}/10")
        print(f"   Classification: {quality_text} (Score: {class_prediction})")
        
        print("\n✅ Model test completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Error testing model: {e}")
        return False

if __name__ == "__main__":
    test_lightgbm_model() 