from flask import Flask, request, render_template, jsonify
import pickle
import pandas as pd
import numpy as np

app = Flask(__name__)

# Load the LightGBM model objects
try:
    with open("lightgbm_model.pkl", "rb") as f:
        model_objects = pickle.load(f)
    
    regressor = model_objects['regressor']
    classifier = model_objects['classifier']
    scaler = model_objects['scaler']
    label_encoders = model_objects['label_encoders']
    feature_names = model_objects['feature_names']
    categorical_cols = model_objects['categorical_cols']
    
    print("✅ LightGBM models loaded successfully!")
    print(f"📊 Features: {len(feature_names)}")
    print(f"🔧 Categorical columns: {categorical_cols}")
    
except Exception as e:
    print(f"❌ Error loading model: {e}")
    print("💡 Please run 'python train_lightgbm_model.py' first to train and save the model")
    exit()

# Define expected columns based on the dataset
REQUIRED_COLUMNS = [
    'Age', 'Gender', 'Sleep Start Time', 'Sleep End Time', 'Total Sleep Hours',
    'Exercise (mins/day)', 'Caffeine Intake (mg)', 'Screen Time Before Bed (mins)',
    'Work Hours (hrs/day)', 'Productivity Score', 'Mood Score', 'Stress Level'
]

@app.route("/")
def home():
    return render_template("index.html", 
                         input_data={col: "" for col in REQUIRED_COLUMNS},
                         prediction_text="")

@app.route("/predictor")
def predictor():
    return render_template("predictor.html", 
                         input_data={col: "" for col in REQUIRED_COLUMNS},
                         prediction_text="")

@app.route("/predictor.html")
def predictor_html():
    return render_template("predictor.html", 
                         input_data={col: "" for col in REQUIRED_COLUMNS},
                         prediction_text="")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        # Get form data
        form_data = request.form.to_dict()
        
        # Create DataFrame with all required columns
        input_data = {}
        for col in REQUIRED_COLUMNS:
            value = form_data.get(col, "")
            if col in ['Age', 'Sleep Start Time', 'Sleep End Time', 'Total Sleep Hours', 
                      'Exercise (mins/day)', 'Caffeine Intake (mg)', 'Screen Time Before Bed (mins)',
                      'Work Hours (hrs/day)', 'Productivity Score', 'Mood Score', 'Stress Level']:
                input_data[col] = float(value) if value else 0.0
            else:
                input_data[col] = value if value else ""
        
        # Create DataFrame
        input_df = pd.DataFrame([input_data])
        
        # Preprocess the input data
        processed_df = preprocess_input(input_df)
        
        # Make predictions
        reg_prediction = regressor.predict(processed_df)[0]
        class_prediction = classifier.predict(processed_df)[0]
        
        # Convert classification prediction to text
        quality_map = {0: "Poor", 1: "Average", 2: "Good"}
        quality_text = quality_map.get(class_prediction, "Unknown")
        
        # Create detailed response
        result = {
            'regression_score': round(reg_prediction, 2),
            'classification_quality': quality_text,
            'classification_score': int(class_prediction),
            'input_data': input_data
        }
        
        return render_template("predictor.html",
                            input_data=input_data,
                            prediction_text=f"Sleep Quality Score: {result['regression_score']}/10 ({quality_text})",
                            result=result)
    
    except Exception as e:
        error_msg = f"Error during prediction: {str(e)}"
        print(f"❌ {error_msg}")
        return render_template("predictor.html",
                            input_data=form_data,
                            prediction_text=f"Error: {error_msg}")

@app.route("/api/predict", methods=["POST"])
def api_predict():
    """API endpoint for JSON predictions"""
    try:
        data = request.get_json()
        
        # Create DataFrame from JSON data
        input_df = pd.DataFrame([data])
        
        # Preprocess the input data
        processed_df = preprocess_input(input_df)
        
        # Make predictions
        reg_prediction = regressor.predict(processed_df)[0]
        class_prediction = classifier.predict(processed_df)[0]
        
        # Convert classification prediction to text
        quality_map = {0: "Poor", 1: "Average", 2: "Good"}
        quality_text = quality_map.get(class_prediction, "Unknown")
        
        return jsonify({
            'success': True,
            'regression_score': round(reg_prediction, 2),
            'classification_quality': quality_text,
            'classification_score': int(class_prediction),
            'message': f"Sleep Quality Score: {round(reg_prediction, 2)}/10 ({quality_text})"
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

def preprocess_input(input_df):
    """Preprocess input data to match training format"""
    try:
        # Create a copy to avoid modifying original
        df = input_df.copy()
        
        # Apply label encoding to categorical columns
        for col in categorical_cols:
            if col in df.columns and col in label_encoders:
                # Handle unseen categories by using the most common category
                unique_values = label_encoders[col].classes_
                df[col] = df[col].apply(lambda x: x if x in unique_values else unique_values[0])
                df[col] = label_encoders[col].transform(df[col])
        
        # Ensure all required columns are present
        for col in feature_names:
            if col not in df.columns:
                df[col] = 0  # Default value for missing columns
        
        # Reorder columns to match training data
        df = df[feature_names]
        
        # Apply scaling
        scaled_data = scaler.transform(df)
        scaled_df = pd.DataFrame(scaled_data, columns=feature_names)
        
        return scaled_df
    
    except Exception as e:
        print(f"❌ Error in preprocessing: {e}")
        raise e

@app.route("/health")
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'model_loaded': True,
        'features': len(feature_names),
        'categorical_columns': categorical_cols
    })

if __name__ == "__main__":
    print("🚀 Starting Flask app with LightGBM model...")
    print(f"📊 Available features: {feature_names}")
    print(f"🔧 Categorical columns: {categorical_cols}")
    app.run(debug=True, port=5001)