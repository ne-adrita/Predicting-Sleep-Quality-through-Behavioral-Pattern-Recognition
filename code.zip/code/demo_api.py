import requests
import json

def test_api():
    """Demo script to test the API endpoints"""
    
    # API base URL
    base_url = "http://localhost:5001"
    
    print("🚀 Testing Sleep Quality Prediction API")
    print("=" * 50)
    
    # Test 1: Health check
    print("\n1️⃣ Testing health endpoint...")
    try:
        response = requests.get(f"{base_url}/health")
        if response.status_code == 200:
            print("✅ Health check passed!")
            print(f"   Status: {response.json()}")
        else:
            print(f"❌ Health check failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Health check error: {e}")
    
    # Test 2: API prediction
    print("\n2️⃣ Testing prediction API...")
    
    # Sample data
    sample_data = {
        "Gender": "Male",
        "Age": 35,
        "Occupation": "Engineer",
        "Sleep Duration": 7.5,
        "Physical Activity Level": 60,
        "Stress Level": 5,
        "BMI Category": "Normal",
        "Blood Pressure": "120/80",
        "Heart Rate": 70,
        "Daily Steps": 7500
    }
    
    print("📊 Sample data:")
    for key, value in sample_data.items():
        print(f"   {key}: {value}")
    
    try:
        response = requests.post(
            f"{base_url}/api/predict",
            json=sample_data,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Prediction successful!")
            print(f"   Regression Score: {result['regression_score']}/10")
            print(f"   Classification: {result['classification_quality']}")
            print(f"   Message: {result['message']}")
        else:
            print(f"❌ Prediction failed: {response.status_code}")
            print(f"   Error: {response.text}")
    except Exception as e:
        print(f"❌ Prediction error: {e}")
    
    # Test 3: Multiple predictions
    print("\n3️⃣ Testing multiple predictions...")
    
    test_cases = [
        {
            "name": "High Quality Sleep",
            "data": {
                "Gender": "Female",
                "Age": 28,
                "Occupation": "Doctor",
                "Sleep Duration": 8.5,
                "Physical Activity Level": 75,
                "Stress Level": 3,
                "BMI Category": "Normal",
                "Blood Pressure": "115/75",
                "Heart Rate": 65,
                "Daily Steps": 8500
            }
        },
        {
            "name": "Poor Quality Sleep",
            "data": {
                "Gender": "Male",
                "Age": 45,
                "Occupation": "Manager",
                "Sleep Duration": 5.5,
                "Physical Activity Level": 30,
                "Stress Level": 8,
                "BMI Category": "Overweight",
                "Blood Pressure": "140/95",
                "Heart Rate": 85,
                "Daily Steps": 3000
            }
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n   Test Case {i}: {test_case['name']}")
        try:
            response = requests.post(
                f"{base_url}/api/predict",
                json=test_case['data'],
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                result = response.json()
                print(f"   ✅ Score: {result['regression_score']}/10 ({result['classification_quality']})")
            else:
                print(f"   ❌ Failed: {response.status_code}")
        except Exception as e:
            print(f"   ❌ Error: {e}")
    
    print("\n" + "=" * 50)
    print("🎉 API testing completed!")
    print("\nTo use the web interface, visit:")
    print(f"   {base_url}")
    print("\nTo make API calls from your application:")
    print("   POST /api/predict with JSON data")
    print("   GET /health for system status")

if __name__ == "__main__":
    test_api() 